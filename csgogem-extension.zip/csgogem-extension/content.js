// Inject the page-context script so it can wrap fetch before any requests fire
const script = document.createElement("script");
script.src = chrome.runtime.getURL("inject.js");
script.onload = () => script.remove();
(document.head || document.documentElement).appendChild(script);

// Listen for data from inject.js
window.addEventListener("message", (event) => {
  if (
    event.source !== window ||
    event.data?.type !== "CSGOGEM_REWARDS_DATA"
  ) {
    return;
  }

  const rakeback = event.data.payload?.rakeback;

  const injectRakebackButton = (period, xpathIndex, value) => {
    const result = document.evaluate(
      `/html/body/div[1]/div/div/main/div[2]/div[2]/div[2]/div[${xpathIndex}]/div/div/div[4]`,
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    );
    const target = result.singleNodeValue;
    if (!target) return false;
    if (target.querySelector(`#csgogem-${period}-btn`)) return true; // already injected

    const btn = document.createElement("button");
    btn.id = `csgogem-${period}-btn`;
    btn.type = "button";
    btn.className =
      "v-btn v-btn--block v-btn--flat v-btn--readonly v-theme--dark bg-darkgrey400 text-lightgrey100 v-btn--density-default rounded-lg v-btn--variant-elevated brand-btn brand-btn--secondary";
    btn.setAttribute("tabindex", "-1");
    btn.style.cssText = "width: 44px; height: 44px;";

    const label = document.createElement("span");
    label.id = `csgogem-${period}-rakeback`;
    label.className = "text-body-2 text-uppercase font-weight-bold";
    label.textContent = value / 100;

    btn.innerHTML = `<span class="v-btn__content" data-no-activator=""></span>`;
    btn.querySelector(".v-btn__content").appendChild(label);

    target.appendChild(btn);
    return true;
  };

  for (const [period, xpathIndex] of [["weekly", 4], ["monthly", 5]]) {
    const value = rakeback?.[period].current;
    if (!injectRakebackButton(period, xpathIndex, value)) {
      let attempts = 0;
      const interval = setInterval(() => {
        if (injectRakebackButton(period, xpathIndex, value) || ++attempts >= 20) clearInterval(interval);
      }, 100);
    }
  }
});
