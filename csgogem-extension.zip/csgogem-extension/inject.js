// Runs in page context — intercepts fetch calls to getUserRewards
(function () {
  const TARGET_URL = "https://api.csgogem.com/app/getUserRewards";
  const originalFetch = window.fetch;

  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url;

    if (url && url.startsWith(TARGET_URL)) {
      const clone = response.clone();
      clone
        .json()
        .then((data) => {
          window.postMessage(
            { type: "CSGOGEM_REWARDS_DATA", payload: data },
            "*"
          );
        })
        .catch(() => {
          clone.text().then((text) => {
            window.postMessage(
              { type: "CSGOGEM_REWARDS_DATA", payload: text },
              "*"
            );
          });
        });
    }

    return response;
  };
})();
